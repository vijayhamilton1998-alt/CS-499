'use strict';

const mongoose = require('mongoose');

const dbURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/travlr';

mongoose.connect(dbURI)
  .then(() => console.log('MongoDB connection established'))
  .catch((err) => console.error('MongoDB connection error:', err.message));

process.on('SIGINT', async () => {
  await mongoose.connection.close();
  process.exit(0);
});

require('./trip');
