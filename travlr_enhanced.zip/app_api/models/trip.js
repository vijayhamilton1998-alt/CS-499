'use strict';

const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    uppercase: true,
    minlength: 4,
    maxlength: 20
  },
  name: { type: String, required: true, trim: true, maxlength: 120 },
  length: { type: String, required: true, trim: true, maxlength: 60 },
  start: { type: Date, required: true },
  resort: { type: String, required: true, trim: true, maxlength: 120 },
  perPerson: { type: Number, required: true, min: 0, max: 100000 },
  image: { type: String, required: true, trim: true, maxlength: 255 },
  description: { type: String, required: true, trim: true, maxlength: 1000 }
}, {
  timestamps: true,
  versionKey: false
});

tripSchema.index({ name: 1 });
tripSchema.index({ start: 1, perPerson: 1 });

mongoose.model('Trip', tripSchema);
