'use strict';

const express = require('express');
const router = express.Router();
const trips = require('../controllers/trips');

router.get('/trips', trips.list);
router.get('/trips/:tripCode', trips.getByCode);
router.post('/trips', trips.create);
router.put('/trips/:tripCode', trips.update);
router.delete('/trips/:tripCode', trips.remove);

module.exports = router;
