'use strict';

const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

const allowedSorts = new Set(['name', 'perPerson', 'start']);

function cleanTrip(body = {}) {
  return {
    code: String(body.code || '').trim().toUpperCase(),
    name: String(body.name || '').trim(),
    length: String(body.length || '').trim(),
    start: body.start,
    resort: String(body.resort || '').trim(),
    perPerson: Number(body.perPerson),
    image: String(body.image || '').trim(),
    description: String(body.description || '').trim()
  };
}

function validationMessage(err) {
  if (err?.code === 11000) return 'Trip code must be unique.';
  if (err?.name === 'ValidationError') {
    return Object.values(err.errors).map((e) => e.message).join(' ');
  }
  return 'Unable to process trip data.';
}

exports.list = async (req, res, next) => {
  try {
    const query = {};
    const search = String(req.query.search || '').trim();
    const maxPrice = Number(req.query.maxPrice);
    if (search) {
      const escaped = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      query.$or = [
        { name: { $regex: escaped, $options: 'i' } },
        { resort: { $regex: escaped, $options: 'i' } },
        { code: { $regex: escaped, $options: 'i' } }
      ];
    }
    if (Number.isFinite(maxPrice) && maxPrice >= 0) query.perPerson = { $lte: maxPrice };

    const sortField = allowedSorts.has(req.query.sort) ? req.query.sort : 'start';
    const order = req.query.order === 'desc' ? -1 : 1;
    const trips = await Trip.find(query).sort({ [sortField]: order, code: 1 }).lean();
    res.json(trips);
  } catch (err) { next(err); }
};

exports.getByCode = async (req, res, next) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode.toUpperCase() }).lean();
    if (!trip) return res.status(404).json({ message: 'Trip not found.' });
    res.json(trip);
  } catch (err) { next(err); }
};

exports.create = async (req, res, next) => {
  try {
    const trip = await Trip.create(cleanTrip(req.body));
    res.status(201).json(trip);
  } catch (err) {
    if (err?.name === 'ValidationError' || err?.code === 11000) {
      return res.status(400).json({ message: validationMessage(err) });
    }
    next(err);
  }
};

exports.update = async (req, res, next) => {
  try {
    const updated = await Trip.findOneAndUpdate(
      { code: req.params.tripCode.toUpperCase() },
      cleanTrip(req.body),
      { new: true, runValidators: true }
    );
    if (!updated) return res.status(404).json({ message: 'Trip not found.' });
    res.json(updated);
  } catch (err) {
    if (err?.name === 'ValidationError' || err?.code === 11000) {
      return res.status(400).json({ message: validationMessage(err) });
    }
    next(err);
  }
};

exports.remove = async (req, res, next) => {
  try {
    const deleted = await Trip.findOneAndDelete({ code: req.params.tripCode.toUpperCase() });
    if (!deleted) return res.status(404).json({ message: 'Trip not found.' });
    res.status(204).end();
  } catch (err) { next(err); }
};
