'use strict';

const state = { trips: [], filtered: [] };
const $ = (id) => document.getElementById(id);

async function loadTrips() {
  const status = $('trip-status');
  try {
    let response = await fetch('/api/trips');
    if (!response.ok) throw new Error('API unavailable');
    state.trips = await response.json();
    status.textContent = 'Live data loaded from the Travlr API.';
  } catch (_) {
    const response = await fetch('data/trips.json');
    state.trips = await response.json();
    status.textContent = 'Demo data loaded locally. Start the Node/MongoDB application to use the live API.';
  }
  applyFilters();
}

function normalized(value) { return String(value ?? '').trim().toLowerCase(); }

function applyFilters() {
  const query = normalized($('trip-search').value);
  const max = Number($('max-price').value);
  const sort = $('trip-sort').value;

  // Linear scan: O(n). This is appropriate for the small client-side collection.
  state.filtered = state.trips.filter((trip) => {
    const haystack = normalized(`${trip.code} ${trip.name} ${trip.resort} ${trip.description}`);
    const matchesText = !query || haystack.includes(query);
    const matchesPrice = !Number.isFinite(max) || max <= 0 || Number(trip.perPerson) <= max;
    return matchesText && matchesPrice;
  });

  // JavaScript's built-in stable sort is O(n log n) for typical engines.
  state.filtered.sort((a, b) => {
    if (sort === 'price-asc') return Number(a.perPerson) - Number(b.perPerson);
    if (sort === 'price-desc') return Number(b.perPerson) - Number(a.perPerson);
    if (sort === 'name') return String(a.name).localeCompare(String(b.name));
    return new Date(a.start) - new Date(b.start);
  });

  renderTrips();
}

function renderTrips() {
  const list = $('trip-list');
  list.replaceChildren();
  if (!state.filtered.length) {
    const item = document.createElement('li');
    item.className = 'status';
    item.textContent = 'No trips match the selected criteria.';
    list.appendChild(item);
    return;
  }

  for (const trip of state.filtered) {
    const li = document.createElement('li');
    li.className = 'trip-card';

    const img = document.createElement('img');
    img.src = trip.image;
    img.alt = `${trip.name} destination`;

    const body = document.createElement('div');
    body.className = 'trip-body';
    const h2 = document.createElement('h2'); h2.textContent = trip.name;
    const code = document.createElement('p'); code.className = 'trip-meta'; code.textContent = `Code: ${trip.code}`;
    const length = document.createElement('p'); length.className = 'trip-meta'; length.textContent = trip.length;
    const date = document.createElement('p'); date.className = 'trip-meta'; date.textContent = `Starts: ${new Date(trip.start).toLocaleDateString()}`;
    const price = document.createElement('p'); price.className = 'trip-price'; price.textContent = `$${Number(trip.perPerson).toLocaleString()} per person`;
    const desc = document.createElement('p'); desc.textContent = trip.description;

    body.append(h2, code, length, date, price, desc);
    li.append(img, body);
    list.appendChild(li);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  $('trip-search').addEventListener('input', applyFilters);
  $('max-price').addEventListener('input', applyFilters);
  $('trip-sort').addEventListener('change', applyFilters);
  $('clear-filters').addEventListener('click', () => {
    $('trip-search').value = '';
    $('max-price').value = '';
    $('trip-sort').value = 'start';
    applyFilters();
  });
  loadTrips();
});
