'use strict';

const form = document.getElementById('trip-form');
const statusBox = document.getElementById('admin-status');
const tbody = document.getElementById('trip-rows');
let trips = [];

function formData() {
  const data = Object.fromEntries(new FormData(form).entries());
  data.perPerson = Number(data.perPerson);
  return data;
}

function validateTrip(t) {
  const errors = [];
  if (!/^[A-Z0-9-]{4,20}$/i.test(t.code)) errors.push('Code must be 4-20 letters, numbers, or hyphens.');
  if (!t.name || t.name.length > 120) errors.push('Name is required and must be 120 characters or fewer.');
  if (!t.start || Number.isNaN(Date.parse(t.start))) errors.push('A valid start date is required.');
  if (!Number.isFinite(t.perPerson) || t.perPerson < 0) errors.push('Price must be a non-negative number.');
  if (!t.description || t.description.length > 1000) errors.push('Description is required and must be 1000 characters or fewer.');
  return errors;
}

async function fetchTrips() {
  try {
    const res = await fetch('/api/trips?sort=start');
    if (!res.ok) throw new Error('Start the Node/MongoDB application to use admin CRUD.');
    trips = await res.json();
    renderRows();
    statusBox.textContent = 'Connected to the Travlr API.';
  } catch (err) {
    statusBox.textContent = err.message;
  }
}

function renderRows() {
  tbody.replaceChildren();
  for (const trip of trips) {
    const tr = document.createElement('tr');
    for (const value of [trip.code, trip.name, `$${Number(trip.perPerson).toLocaleString()}`]) {
      const td = document.createElement('td'); td.textContent = value; tr.appendChild(td);
    }
    const actions = document.createElement('td');
    const edit = document.createElement('button'); edit.type = 'button'; edit.textContent = 'Edit';
    edit.addEventListener('click', () => fillForm(trip));
    const del = document.createElement('button'); del.type = 'button'; del.textContent = 'Delete'; del.style.marginLeft = '6px';
    del.addEventListener('click', () => removeTrip(trip.code));
    actions.append(edit, del); tr.appendChild(actions); tbody.appendChild(tr);
  }
}

function fillForm(trip) {
  for (const [key, value] of Object.entries(trip)) {
    if (!form.elements[key]) continue;
    form.elements[key].value = key === 'start' ? String(value).slice(0,10) : value;
  }
  form.dataset.originalCode = trip.code;
}

async function removeTrip(code) {
  if (!confirm(`Delete ${code}?`)) return;
  const res = await fetch(`/api/trips/${encodeURIComponent(code)}`, { method: 'DELETE' });
  statusBox.textContent = res.ok ? 'Trip deleted.' : 'Unable to delete trip.';
  if (res.ok) fetchTrips();
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const trip = formData();
  const errors = validateTrip(trip);
  if (errors.length) { statusBox.textContent = errors.join(' '); return; }

  const originalCode = form.dataset.originalCode;
  const url = originalCode ? `/api/trips/${encodeURIComponent(originalCode)}` : '/api/trips';
  const method = originalCode ? 'PUT' : 'POST';
  const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(trip) });
  const payload = res.status === 204 ? {} : await res.json().catch(() => ({}));
  statusBox.textContent = res.ok ? `Trip ${originalCode ? 'updated' : 'created'}.` : (payload.message || 'Unable to save trip.');
  if (res.ok) { form.reset(); delete form.dataset.originalCode; fetchTrips(); }
});

document.getElementById('reset-form').addEventListener('click', () => { form.reset(); delete form.dataset.originalCode; statusBox.textContent = 'Form cleared.'; });
fetchTrips();
