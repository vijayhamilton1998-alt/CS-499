# Travlr Getaways — CS 499 Enhanced Artifact

This project started as the static Travlr Getaways website contained in the original artifact. The enhanced version preserves the original pages and imagery while adding source code that demonstrates the three CS 499 enhancement categories.

## Enhancement 1 — Software Design and Engineering

- Added a Node.js/Express application entry point (`server.js`).
- Separated the REST API into routes, controllers, and Mongoose models under `app_api/`.
- Added centralized server error handling and basic defensive HTTP headers.
- Added reusable client-side modules under `js/` instead of embedding application logic in HTML.
- Added responsive, reusable enhancement styles in `css/enhancements.css`.
- Corrected the Travel page structure and replaced hard-coded reef entries with data-driven rendering.

## Enhancement 2 — Algorithms and Data Structures

- Added search across trip code, name, resort, and description.
- Added maximum-price filtering using a linear O(n) scan of the in-memory trip collection.
- Added sorting by date, name, and price. Sorting uses the JavaScript runtime's stable comparison sort (typically O(n log n)).
- Kept trip records as structured objects, enabling consistent transformations and display.
- Added server-side query filtering and sort parameters so larger datasets can be processed closer to the database.

## Enhancement 3 — Databases

- Added MongoDB/Mongoose persistence through `app_api/models/db.js` and `trip.js`.
- Added schema validation, field length/range constraints, timestamps, a unique trip code, and indexes.
- Added RESTful CRUD endpoints:
  - `GET /api/trips`
  - `GET /api/trips/:tripCode`
  - `POST /api/trips`
  - `PUT /api/trips/:tripCode`
  - `DELETE /api/trips/:tripCode`
- Added an administration page (`admin.html`) that demonstrates validated CRUD requests.
- Added duplicate-code and validation error handling without exposing stack traces to users.

## Run the enhanced application

1. Install Node.js and MongoDB.
2. Copy `.env.example` to `.env` and change `MONGODB_URI` if needed.
3. Run `npm install`.
4. Seed MongoDB with the records in `data/trips.seed.json` using your preferred MongoDB import workflow.
5. Run `npm start`.
6. Open `http://localhost:3000/travel.html`.

The Travel page also falls back to `data/trips.json` if the API is unavailable, which allows the search/sort/filter enhancement to be demonstrated as a static site.

## Security notes

- `.env` is excluded by `.gitignore`; no credentials are included in this artifact.
- JSON request bodies are size-limited.
- Mongoose validation is enabled for create and update operations.
- User-controlled data is rendered with `textContent` in the client to reduce XSS risk.
- Error responses use generic messages rather than returning server stack traces.

## Original artifact preservation

The original static pages and images remain in the project so reviewers can compare the earlier structure with the enhanced functionality. The most visibly enhanced pages are `travel.html` and `admin.html`.
